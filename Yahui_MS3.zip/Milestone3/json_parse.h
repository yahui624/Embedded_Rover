#ifndef JSON_PARSE_H
#define JSON_PARSE_H

int parse(char *message);

#endif
